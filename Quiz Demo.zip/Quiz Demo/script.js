let que_tag = document.getElementById("question");
let option1 = document.getElementById("option1");
let option2 = document.getElementById("option2");
let option3 = document.getElementById("option3");
let option4 = document.getElementById("option4");
let next = document.getElementById("next");
let quizLength = document.getElementById("quizLength");
let currentQuestion = document.getElementById("questionNumber");
let time = document.getElementById("seconds");

let questions = {
  question1: {
    question: "HTML stands for -",
    options: [
      "HighText Machine Language",
      "HyperText and links Markup Language",
      "HyperText Markup Language",
      "None of these",
    ],
    answer: "HyperText Markup Language",
  },

  question2: {
    question:
      "Which of the following element is responsible for making the text bold in HTML?",
    options: ["pre", "a", "b", "br"],
    answer: "b",
  },

  question3: {
    question:
      "Which of the following tag is used for inserting the largest heading in HTML?",
    options: ["h3", "h1", "h5", "h6"],
    answer: "h1",
  },

  question4: {
    question:
      "Which of the following tag is used to insert a line-break in HTML?",
    options: ["br", "a", "pre", "b"],
    answer: "br",
  },

  question5: {
    question:
      "Which of the following element is responsible for making the text italic in HTML?",
    options: ["i", "italic", "it", "pre"],
    answer: "i",
  },
};

let que_obj = JSON.stringify(questions);
let list = JSON.parse(que_obj);
let score = 0;
let length = 0;
let second = 30;

for (let i in list) {
  length++;
}

quizLength.innerText = length;

let timer = setInterval(() => {
  if (second !== 0) {
    second--;
    time.innerText = second;
  } else {
    nextQuestion(Number(currentQuestion.innerText));
  second = 30;

  }
}, 1000);

function nextQuestion(current = 0) {
  second = 30;
  let n = 0;
  if (current == 0) {
    n = 1;
  } else {
    n = current + 1;
  }

  if (n <= length) {
    removeClass();
    que_tag.innerText = list[`question${n}`].question;
    option1.innerHTML = list[`question${n}`].options[0];
    option2.innerHTML = list[`question${n}`].options[1];
    option3.innerHTML = list[`question${n}`].options[2];
    option4.innerHTML = list[`question${n}`].options[3];
    currentQuestion.innerText = current + 1;
  } else {
    alert(`Your Score is ${score}`);
    clearTimeout(timer);
    location.reload();
  }
}

next.addEventListener("click", () => {
  nextQuestion(Number(currentQuestion.innerText));
});

document.getElementById("optionsList").addEventListener("click", (e) => {
  if (e.target.tagName === "LI") {
    if (
      e.target.innerText === list[`question${currentQuestion.innerText}`].answer
    ) {
      ++score;
      e.target.classList.toggle("right");
      nextQuestion(Number(currentQuestion.innerText));
    } else {
      e.target.classList.toggle("wrong");
      nextQuestion(Number(currentQuestion.innerText));
    }
  }
});

function removeClass() {
  option1.classList.remove("wrong");
  option2.classList.remove("wrong");
  option3.classList.remove("wrong");
  option4.classList.remove("wrong");
  option1.classList.remove("right");
  option2.classList.remove("right");
  option3.classList.remove("right");
  option4.classList.remove("right");
}

nextQuestion();
